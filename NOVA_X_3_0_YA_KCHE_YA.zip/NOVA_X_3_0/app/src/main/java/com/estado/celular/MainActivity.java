package com.estado.celular;

import android.app.Activity;
import android.animation.ObjectAnimator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import org.json.JSONObject;
import java.net.URL;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.nio.charset.StandardCharsets;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.provider.Settings;
import android.graphics.Canvas;
import android.graphics.Paint;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(9, 10, 26);
    private static final int CARD = Color.rgb(24, 25, 54);
    private static final int STROKE = Color.rgb(55, 55, 93);
    private static final int WHITE = Color.rgb(238, 247, 255);
    private static final int MUTED = Color.rgb(152, 174, 195);
    private static final int CYAN = Color.rgb(255, 149, 97);
    private static final int GREEN = Color.rgb(255, 191, 91);
    private LinearLayout content;
    private final ArrayList<Integer> ramHistory = new ArrayList<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        showIntro();
    }
    @Override public void onResume() {
        super.onResume();
        if (content != null) build();
    }

    private void showIntro() {
        LinearLayout intro = vertical();
        intro.setGravity(Gravity.CENTER);
        intro.setPadding(dp(28), dp(28), dp(28), dp(28));
        intro.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Color.rgb(42, 14, 50), Color.rgb(13, 11, 32), Color.rgb(64, 22, 36)}));
        TextView glyph = t("✦", 76, CYAN, true);
        glyph.setGravity(Gravity.CENTER);
        intro.addView(glyph);
        ObjectAnimator glow = ObjectAnimator.ofFloat(glyph, "alpha", 0.45f, 1f);
        glow.setDuration(700); glow.setRepeatCount(1); glow.setRepeatMode(ObjectAnimator.REVERSE);
        glow.setInterpolator(new AccelerateDecelerateInterpolator()); glow.start();
        addSpace(intro, 12);
        TextView greeting = t("YA KCHE YA", 36, WHITE, true);
        greeting.setGravity(Gravity.CENTER);
        intro.addView(greeting);
        addSpace(intro, 8);
        TextView strap = t("NOVA X  •  TU SISTEMA, TU CONTROL", 13, CYAN, true);
        strap.setGravity(Gravity.CENTER);
        intro.addView(strap);
        setContentView(intro);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (!isFinishing()) build();
        }, 1350);
    }

    private boolean isLocalQuery(String q) {
        String x = q.toLowerCase(Locale.ROOT);
        return x.contains("ram") || x.contains("memoria") || x.contains("bater") || x.contains("carga")
             || x.contains("temper") || x.contains("calient") || x.contains("almacen")
             || x.contains("espacio") || x.contains("android") || x.contains("modelo")
             || x.contains("sistema") || x.contains("optim") || x.contains("limpiar") || x.contains("lenta");
    }

    private String searchWikipedia(String raw) throws Exception {
        String query = raw.replaceAll("[¿?]", " ").replaceAll("(?i)^(hola|nova|oye|por favor|explica|explícame|qué es|quién fue|quien fue|dime sobre|investiga|cuál es|cual es)\\s+", "").trim();
        if (query.isEmpty()) query = raw.trim();
        String url = "https://es.wikipedia.org/w/api.php?action=query&generator=search&gsrlimit=1&gsrsearch="
            + URLEncoder.encode(query, "UTF-8") + "&prop=extracts&exintro=1&explaintext=1&format=json";
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(9500);
        c.setReadTimeout(11000);
        c.setRequestProperty("User-Agent", "NOVA-X-Estudio/3.0 (Android educational reader)");
        try {
            if(c.getResponseCode()!=200) throw new Exception("Respuesta web: " + c.getResponseCode());
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder b = new StringBuilder();
            String line;
            while((line=r.readLine())!=null){ b.append(line); if(b.length()>100000)break; }
            r.close();
            JSONObject pages = new JSONObject(b.toString()).getJSONObject("query").optJSONObject("pages");
            if(pages==null || pages.length()==0)return "No encontré una explicación enciclopédica para esa consulta. Usa «Buscar en Internet» para investigar más.";
            JSONObject page = pages.getJSONObject(pages.keys().next());
            String title = page.optString("title", "Tema");
            String summary = page.optString("extract", "").replaceAll("\\s+", " ").trim();
            if(summary.isEmpty()) return "Encontré «"+title+"», pero no hay una introducción disponible. Usa «Buscar en Internet» para consultar más fuentes.";
            if(summary.length()>900)summary=summary.substring(0,900).replaceAll("\\s+\\S*$", "")+"…";
            return title + "\n\n" + summary + "\n\nFuente: Wikipedia (resumen en línea). Contrasta la información para tus tareas.";
        } finally { c.disconnect(); }
    }

    private void openWebSearch(String raw) {
        String query = raw.trim();
        if(query.isEmpty()) { Toast.makeText(this, "Escribe un tema primero", Toast.LENGTH_SHORT).show(); return; }
        Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)));
        try { startActivity(browser); }
        catch(Exception e) { Toast.makeText(this, "No se encontró un navegador", Toast.LENGTH_SHORT).show(); }
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable background(int color, int borderColor, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (borderColor != 0) d.setStroke(dp(1), borderColor);
        return d;
    }

    private TextView t(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setIncludeFontPadding(true);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private void addSpace(LinearLayout parent, int height) {
        View v = new View(this);
        parent.addView(v, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private LinearLayout card() {
        LinearLayout l = vertical();
        l.setPadding(dp(18), dp(16), dp(18), dp(16));
        l.setBackground(background(CARD, STROKE, 18));
        return l;
    }

    private void addCard(LinearLayout box) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(12);
        content.addView(box, lp);
    }

    private void section(String title) {
        TextView v = t(title, 19, WHITE, true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(15); lp.bottomMargin = dp(10);
        content.addView(v, lp);
    }

    private void detail(LinearLayout box, String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.TOP);
        row.setPadding(0, dp(7), 0, dp(7));
        TextView key = t(label, 14, MUTED, false);
        TextView val = t(value == null || value.isEmpty() ? "No disponible" : value, 14, WHITE, true);
        val.setGravity(Gravity.END);
        row.addView(key, new LinearLayout.LayoutParams(0, -2, 0.43f));
        row.addView(val, new LinearLayout.LayoutParams(0, -2, 0.57f));
        box.addView(row);
    }

    private void meter(LinearLayout card, int percent, int color) {
        LinearLayout track = new LinearLayout(this);
        track.setBackground(background(Color.rgb(42, 62, 81), 0, 100));
        LinearLayout.LayoutParams trackParams = new LinearLayout.LayoutParams(-1, dp(8));
        trackParams.topMargin = dp(12);
        card.addView(track, trackParams);
        View bar = new View(this);
        bar.setBackground(background(color, 0, 100));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, -1, Math.max(0, Math.min(100, percent)));
        track.addView(bar, bp);
        View rest = new View(this);
        track.addView(rest, new LinearLayout.LayoutParams(0, -1, 100 - Math.max(0, Math.min(100, percent))));
    }

    private String gigabytes(long bytes) {
        if (bytes <= 0) return "No disponible";
        return String.format(Locale.getDefault(), "%.1f GB", bytes / 1_000_000_000d);
    }

    private String statusBattery(int status) {
        switch(status) {
            case BatteryManager.BATTERY_STATUS_CHARGING: return "Cargando";
            case BatteryManager.BATTERY_STATUS_FULL: return "Carga completa";
            case BatteryManager.BATTERY_STATUS_DISCHARGING: return "Descargando";
            case BatteryManager.BATTERY_STATUS_NOT_CHARGING: return "Conectada, sin cargar";
            default: return "Desconocido";
        }
    }

    private String healthBattery(int health) {
        switch (health) {
            case BatteryManager.BATTERY_HEALTH_GOOD: return "Normal (según Android)";
            case BatteryManager.BATTERY_HEALTH_OVERHEAT: return "Temperatura elevada";
            case BatteryManager.BATTERY_HEALTH_DEAD: return "Batería deteriorada";
            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE: return "Voltaje elevado";
            case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE: return "Fallo reportado";
            case BatteryManager.BATTERY_HEALTH_COLD: return "Temperatura baja";
            default: return "No disponible";
        }
    }

    private String thermal() {
        if (Build.VERSION.SDK_INT < 29) return "No disponible en este Android";
        PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
        if (power == null) return "No disponible";
        switch(power.getCurrentThermalStatus()) {
            case PowerManager.THERMAL_STATUS_NONE: return "Normal";
            case PowerManager.THERMAL_STATUS_LIGHT: return "Calentamiento leve";
            case PowerManager.THERMAL_STATUS_MODERATE: return "Calentamiento moderado";
            case PowerManager.THERMAL_STATUS_SEVERE: return "Calentamiento alto";
            case PowerManager.THERMAL_STATUS_CRITICAL: return "Calentamiento crítico";
            case PowerManager.THERMAL_STATUS_EMERGENCY: return "Emergencia térmica";
            case PowerManager.THERMAL_STATUS_SHUTDOWN: return "Apagado térmico";
            default: return "No disponible";
        }
    }

    private String novaResponse(String raw) {
        String q = raw.toLowerCase(Locale.ROOT);
        Intent bat = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if(q.trim().isEmpty())return "Escribe tu pregunta: por ejemplo, ¿cuánta RAM tengo libre?";
        if(q.contains("ram") || q.contains("memoria")){
            ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);
            if(am==null)return "Android no entregó información de RAM.";
            ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();am.getMemoryInfo(mi);
            return "Tienes aproximadamente " + gigabytes(mi.availMem) + " de RAM disponible de " + gigabytes(mi.totalMem) + ". Android administra la RAM automáticamente: tener RAM en uso no implica un problema.";
        }
        if(q.contains("bater") || q.contains("carga")){
            if(bat==null)return "No pude consultar la batería.";
            int level=bat.getIntExtra(BatteryManager.EXTRA_LEVEL,-1);
            int scale=bat.getIntExtra(BatteryManager.EXTRA_SCALE,100);
            int pct=scale>0?Math.round(100f*level/scale):-1;
            return "Tu batería está en "+pct+"%. Estado: "+statusBattery(bat.getIntExtra(BatteryManager.EXTRA_STATUS,1))+".";
        }
        if(q.contains("temper") || q.contains("calient")){
            if(bat==null)return "No pude consultar la temperatura de batería.";
            int temp=bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,Integer.MIN_VALUE);
            if(temp==Integer.MIN_VALUE)return "Tu Android no reporta temperatura de batería.";
            return String.format(Locale.getDefault(),"La batería está a %.1f °C. Estado térmico del sistema: %s. Si el teléfono se siente demasiado caliente, déjalo descansar.",temp/10f,thermal());
        }
        if(q.contains("almacen") || q.contains("espacio") || q.contains("disco")){
            File f=Environment.getExternalStorageDirectory();
            return "Tienes "+gigabytes(f.getUsableSpace())+" libres de "+gigabytes(f.getTotalSpace())+" de almacenamiento consultable.";
        }
        if(q.contains("android") || q.contains("modelo") || q.contains("sistema"))return "Tu teléfono es "+Build.MANUFACTURER+" "+Build.MODEL+" con Android "+Build.VERSION.RELEASE+".";
        if(q.contains("optim") || q.contains("limpiar") || q.contains("lenta"))return "Para mejorar el rendimiento, revisa apps que no uses, actualiza el sistema y conserva espacio libre. No recomiendo forzar el cierre de todas las apps: Android gestiona la RAM.";
        return "Todavía soy un asistente local. Puedo responder sobre batería, temperatura, RAM, espacio, Android y optimización segura.";
    }

    private long cleanOwnCache(File dir) {
        if(dir==null || !dir.exists() || !dir.isDirectory())return 0;
        long freed=0;
        File[] files=dir.listFiles();
        if(files==null)return 0;
        for(File f:files){
            if(f.isDirectory())freed+=cleanOwnCache(f);
            else {long size=f.length(); if(f.delete())freed+=size;}
        }
        return freed;
    }

    private class RamGraph extends View {
        private final Paint paint = new Paint(3);
        RamGraph(Context c){super(c);}
        @Override protected void onDraw(Canvas canvas){
            super.onDraw(canvas);
            float w=getWidth(),h=getHeight();
            paint.setStrokeWidth(dp(1));paint.setColor(STROKE);
            for(int i=0;i<5;i++)canvas.drawLine(0,h*i/4,w,h*i/4,paint);
            if(ramHistory.size()<2){paint.setColor(MUTED);paint.setTextSize(dp(12));canvas.drawText("Pulsa Actualizar para crear el gráfico",dp(9),h/2,paint);return;}
            paint.setColor(CYAN);paint.setStrokeWidth(dp(3));
            for(int i=1;i<ramHistory.size();i++){
                float x1=(i-1)*w/(ramHistory.size()-1),x2=i*w/(ramHistory.size()-1);
                float y1=h*(100-ramHistory.get(i-1))/100f,y2=h*(100-ramHistory.get(i))/100f;
                canvas.drawLine(x1,y1,x2,y2,paint);
            }
        }
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        content = vertical();
        content.setPadding(dp(20), dp(28), dp(20), dp(32));
        scroll.addView(content);
        setContentView(scroll);

        TextView brand = t("✦  NOVA X  /  YA KCHE YA", 13, CYAN, true);
        content.addView(brand);
        addSpace(content, 12);
        TextView title = t("Control total,\na simple vista.", 30, WHITE, true);
        content.addView(title);
        addSpace(content, 7);
        TextView subtitle = t("Diagnóstico del celular, gráficos y NOVA para investigar en línea.", 14, MUTED, false);
        content.addView(subtitle);
        addSpace(content, 18);

        LinearLayout hero = card();
        hero.setBackground(background(Color.rgb(54, 25, 61), Color.rgb(157, 68, 72), 20));
        hero.addView(t("DISPOSITIVO", 12, CYAN, true));
        addSpace(hero, 7);
        hero.addView(t(Build.MANUFACTURER + " " + Build.MODEL, 24, WHITE, true));
        hero.addView(t("Android " + Build.VERSION.RELEASE + "   ·   API " + Build.VERSION.SDK_INT, 15, MUTED, false));
        addCard(hero);

        section("Batería");
        Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        LinearLayout b = card();
        if (battery == null) {
            b.addView(t("No se puede consultar la batería", 16, MUTED, false));
        } else {
            int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int percent = scale > 0 && level >= 0 ? Math.round(level * 100f / scale) : -1;
            b.addView(t(percent >= 0 ? percent + "%" : "Sin datos", 34, GREEN, true));
            b.addView(t(statusBattery(battery.getIntExtra(BatteryManager.EXTRA_STATUS, 1)), 14, MUTED, false));
            if (percent >= 0) meter(b, percent, GREEN);
            addSpace(b, 12);
            detail(b, "Salud reportada", healthBattery(battery.getIntExtra(BatteryManager.EXTRA_HEALTH, 1)));
            int temp = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
            if (temp != Integer.MIN_VALUE) detail(b, "Temperatura", String.format(Locale.getDefault(), "%.1f °C", temp / 10f));
            int voltage = battery.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
            if (voltage > 0) detail(b, "Voltaje", String.format(Locale.getDefault(), "%.2f V", voltage / 1000f));
        }
        addCard(b);

        section("Memoria y almacenamiento");
        LinearLayout mem = card();
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        if (manager != null) {
            ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
            manager.getMemoryInfo(info);
            if (info.totalMem > 0) {
                int pct = (int)(100 * (info.totalMem-info.availMem) / info.totalMem);
                ramHistory.add(Math.max(0,Math.min(100,pct)));
                if(ramHistory.size() > 24)ramHistory.remove(0);
            }
            detail(mem, "RAM total", gigabytes(info.totalMem));
            detail(mem, "RAM libre (aprox.)", gigabytes(info.availMem));
            detail(mem, "Uso de RAM (aprox.)", gigabytes(Math.max(0, info.totalMem - info.availMem)));
            detail(mem, "Memoria baja", info.lowMemory ? "Android lo advierte" : "Sin alerta de Android");
        }
        File storage = Environment.getExternalStorageDirectory();
        long total = storage.getTotalSpace();
        long free = storage.getUsableSpace();
        if (total > 0) {
            int usedPercent = (int) Math.round(100.0 * (total - free) / total);
            addSpace(mem, 9);
            mem.addView(t("ALMACENAMIENTO INTERNO", 12, CYAN, true));
            meter(mem, usedPercent, CYAN);
            addSpace(mem, 9);
            detail(mem, "Capacidad", gigabytes(total));
            detail(mem, "Libre", gigabytes(free));
            detail(mem, "Ocupado", usedPercent + "%");
        } else {
            detail(mem, "Almacenamiento", "No disponible");
        }
        addCard(mem);
        LinearLayout history = card();
        history.addView(t("USO DE RAM • HISTORIAL DE ESTA SESIÓN", 12, CYAN, true));
        addSpace(history, 10);
        history.addView(new RamGraph(this), new LinearLayout.LayoutParams(-1, dp(115)));
        addSpace(history, 8);
        history.addView(t("El gráfico guarda una muestra cada vez que pulsas Actualizar.", 12, MUTED, false));
        addCard(history);

        section("Sistema operativo");
        LinearLayout sys = card();
        detail(sys, "Android", Build.VERSION.RELEASE);
        detail(sys, "Nivel API", String.valueOf(Build.VERSION.SDK_INT));
        detail(sys, "Seguridad", Build.VERSION.SDK_INT >= 23 ? Build.VERSION.SECURITY_PATCH : "No disponible");
        detail(sys, "Fabricante", Build.MANUFACTURER);
        detail(sys, "Modelo", Build.MODEL);
        detail(sys, "Hardware", Build.HARDWARE);
        detail(sys, "Arquitectura", Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "Desconocida");
        detail(sys, "Núcleos disponibles", String.valueOf(Runtime.getRuntime().availableProcessors()));
        addCard(sys);

        section("Estado actual");
        LinearLayout state = card();
        detail(state, "Temperatura del sistema", thermal());
        long minutes = SystemClock.elapsedRealtime() / 60000;
        detail(state, "Tiempo encendido", (minutes / 1440) + "d " + ((minutes % 1440) / 60) + "h " + (minutes % 60) + "m");
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        detail(state, "Pantalla (app)", metrics.widthPixels + " × " + metrics.heightPixels + " px");
        detail(state, "Actualizado", new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()));
        addCard(state);

        section("NOVA • Asistente y estudio");
        LinearLayout nova = card();
        nova.addView(t("◈  NOVA ONLINE", 13, CYAN, true));
        addSpace(nova, 5);
        nova.addView(t("Pregúntame por tu celular o investiga un tema escolar. Para consultas generales busco un resumen en Wikipedia con Internet.", 14, MUTED, false));
        addSpace(nova, 12);
        final TextView answer = t("Hola, soy NOVA. Puedo analizar tu batería, RAM y temperatura. Para tareas, escribe un tema como «¿Qué es la fotosíntesis?».", 15, WHITE, false);
        answer.setPadding(dp(12),dp(14),dp(12),dp(14));
        answer.setBackground(background(Color.rgb(38, 38, 77),0,12));
        nova.addView(answer);
        addSpace(nova, 12);
        final EditText question = new EditText(this);
        question.setSingleLine(false);
        question.setMinLines(1);
        question.setMaxLines(3);
        question.setTextSize(15);
        question.setTextColor(WHITE);
        question.setHintTextColor(MUTED);
        question.setHint("Escribe una pregunta o tema escolar...");
        question.setBackground(background(Color.rgb(34, 35, 72), STROKE, 12));
        question.setPadding(dp(12),dp(12),dp(12),dp(12));
        nova.addView(question);
        addSpace(nova, 10);
        Button ask = new Button(this);
        ask.setAllCaps(false);
        ask.setText("Preguntar a NOVA");
        ask.setOnClickListener(v -> {
            String q = question.getText().toString().trim();
            if(q.isEmpty()) { answer.setText("Escribe una pregunta primero."); return; }
            if(isLocalQuery(q)) { answer.setText(novaResponse(q)); return; }
            answer.setText("Consultando fuentes en Internet…");
            new Thread(() -> {
                String result;
                try { result = searchWikipedia(q); }
                catch(Exception e) { result = "No pude conectar con Wikipedia. Comprueba tu Internet o utiliza «Buscar en Internet» para abrir el navegador."; }
                final String finalResult = result;
                runOnUiThread(() -> answer.setText(finalResult));
            }).start();
        });
        nova.addView(ask);
        addSpace(nova, 8);
        Button browse = new Button(this);
        browse.setAllCaps(false);
        browse.setText("Buscar en Internet • Más fuentes");
        browse.setOnClickListener(v -> openWebSearch(question.getText().toString()));
        nova.addView(browse);
        addSpace(nova, 8);
        nova.addView(t("NOVA combina diagnósticos locales con información de Wikipedia. No es un modelo generativo de IA; para resolver tareas complejas o debatir fuentes, revisa la búsqueda web.", 12, MUTED, false));
        addCard(nova);

        section("Optimización segura");
        LinearLayout optimize = card();
        optimize.addView(t("Android reutiliza la RAM disponible como caché para abrir apps más rápido. No es necesario vaciarla constantemente.",14,MUTED,false));
        addSpace(optimize,12);
        Button manage = new Button(this);
        manage.setAllCaps(false);
        manage.setText("Revisar aplicaciones instaladas");
        manage.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_APPLICATION_SETTINGS)));
        optimize.addView(manage);
        addSpace(optimize,8);
        Button clean = new Button(this);
        clean.setAllCaps(false);
        clean.setText("Limpiar caché de NOVA X");
        final TextView result = t("Solo borra archivos temporales de esta aplicación; no cierra otras apps.",12,MUTED,false);
        clean.setOnClickListener(v -> {
            long cleared = cleanOwnCache(getCacheDir());
            result.setText("Se eliminaron " + cleared + " bytes de caché de NOVA X. Esto no libera RAM de otras apps.");
        });
        optimize.addView(clean);
        addSpace(optimize,8);
        optimize.addView(result);
        addCard(optimize);

        TextView refresh = t("↻   Actualizar datos", 16, BG, true);
        refresh.setGravity(Gravity.CENTER);
        refresh.setPadding(dp(14), dp(15), dp(14), dp(15));
        refresh.setBackground(background(CYAN, 0, 14));
        refresh.setOnClickListener(v -> build());
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(10);
        content.addView(refresh, rp);
        addSpace(content, 16);
        TextView note = t("Privacidad: las mediciones del teléfono se procesan localmente. Solo las preguntas escolares que envías a búsqueda en línea se consultan en Wikipedia o se abren en el navegador. NOVA no puede liberar RAM de otras apps ni garantiza diagnósticos de hardware.", 12, MUTED, false);
        content.addView(note);
    }
}

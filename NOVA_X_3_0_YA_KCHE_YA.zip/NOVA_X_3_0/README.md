# NOVA X 3.0 — YA KCHE YA

Aplicación Android nativa en Java, derivada de Estado Celular 2.0.

- Nuevo nombre visible: **NOVA X**.
- Pantalla introductoria: **YA KCHE YA**.
- Interfaz nocturna violeta, medidores, información de batería, RAM, almacenamiento, Android y gráfico de RAM.
- Asistente NOVA con respuestas locales sobre el móvil.
- NOVA también busca resúmenes educativos en Wikipedia (necesita Internet).
- Botón para investigar más en el navegador.
- No incluye una IA generativa ni acceso a ChatGPT; para tener un modelo conversacional completo sería necesario un backend con autenticación y API (nunca incrustar claves en el APK).
- Limpieza únicamente de la caché propia y acceso a Ajustes para gestionar apps; Android no deja vaciar libremente la RAM de apps ajenas.
- No se envían datos del dispositivo a Wikipedia. Solo la consulta escolar elegida por el usuario.

## Compilar desde el teléfono

Sube el ZIP del proyecto al repositorio de GitHub y utiliza el flujo `generar-apk.yml` de la raíz, o extrae los archivos y usa el flujo dentro del proyecto. Requiere Java 17, Gradle 8.9 y SDK Android 35. Tras compilar, descarga `NOVA-X-APK` en Actions / Artifacts.

**Aviso:** el APK de GitHub Actions se firma con un certificado de prueba y puede no actualizar otra instalación con firma distinta. Haz copia de los datos necesarios antes de desinstalar la app antigua.

# Cómo obtener el APK de Estado Celular

El archivo APK **no está precompilado** en este paquete. El proyecto incluye un proceso de GitHub Actions que lo compila usando Android SDK 35 + Java 17 + Gradle 8.9.

## Opción A: Android Studio (computadora)

1. Descarga y descomprime `EstadoCelular_para_compilar_APK.zip`.
2. Abre la carpeta `EstadoCelular` en Android Studio.
3. Deja que Android Studio sincronice el proyecto e instale el SDK que solicite.
4. Usa **Build > Build Bundle(s) / APK(s) > Build APK(s)** (nombre del menú según la versión).
5. El archivo estará normalmente en `EstadoCelular/app/build/outputs/apk/debug/app-debug.apk`.

## Opción B: GitHub Actions (sin instalar Android Studio)

1. Crea un repositorio privado nuevo en GitHub, por ejemplo `estado-celular`.
2. Descomprime el ZIP y sube **los archivos de dentro de la carpeta `EstadoCelular` a la raíz del repositorio**, manteniendo las carpetas `app` y `.github/workflows`. No subas solamente el ZIP.
3. Ve a la pestaña **Actions** del repositorio. Abre **Generar APK de Estado Celular**, pulsa **Run workflow** y confirma.
4. Una vez que termine con éxito, abre su ejecución y descarga el artefacto **EstadoCelular-APK**.
5. Descomprime el archivo que descarga GitHub: dentro está `app-debug.apk`, listo para instalar en Android. Revisa el nombre del archivo antes de instalarlo.

La primera ejecución podría descargar dependencias y tardar varios minutos. Si el proyecto se sube correctamente a la rama `main` o `master`, también se inicia una compilación automáticamente.

## Privacidad y seguridad

- El APK de desarrollo se firma con una clave de depuración generada automáticamente. Es adecuado para probar la app en tu teléfono, no para publicarla en Google Play.
- La app no solicita permisos peligrosos ni permiso de Internet.
- Solo instálala si has compilado el proyecto de una fuente que controlas.
- Algunos teléfonos muestran advertencias al instalar APK fuera de Google Play: verifica que sea tu archivo antes de continuar.

**Limitación:** los estados de batería y temperatura son los que Android informa. No representan un diagnóstico definitivo del hardware.
